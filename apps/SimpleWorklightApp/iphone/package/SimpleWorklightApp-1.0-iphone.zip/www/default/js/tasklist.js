
/* JavaScript content from js/tasklist.js in folder common */
/**
 * 
 */

$("#message").html(userDetails);